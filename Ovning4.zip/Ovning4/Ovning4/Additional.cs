﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ovning4
{
    public class Additional
    {
//        Iteration Types: Recursion and Iteration(Optional if available)
//To find out more about how important it is to think about how much is stacked
//There is also this chapter on recursion and iteration.For someone who is not employed, recursion can be made
//and iteration look very similar, because a recursion can be seen as an iteration of itself
//self.
//Recursion is a function that calls itself, down to a base case, and then does all
//calculations up to the call that initiated the recursion.Below is an example of how
//A recursive method can calculate the nth odd number.
//The method does is to check if n is zero, if it returns the first odd number 1.
//Otherwise, it calls itself for a smaller n and adds two.
//Exercise 5: Recursion
//1. Illustrate the recursiveOdd (1), RecursiveOdd (3) and RecursiveOdd(5) progresses on
//paper to understand the recursive loop.
//2. Write a RecursiveEven (int n) method that recursively calculates the nth even number.
//3. Implement a recursive function to calculate numbers in the fibronase sequence: (f (n) =
//f(n - 1) + f(n - 2))
        public int recursiveOdd(int i)
        {
            if (i==0)
            {
                return 1;
            }
            else 
            return (recursiveOdd(i-1)+2) ;
        }
        public int recursiveEven(int i)
        {
            if (i == 0)
            {
                return 2;
            }
            else
                return (recursiveEven(i - 1) + 2);
        }
        public int fibronase(int i)
        {
            if (i == 0)
            { return 1; }
            else if (i == 1)
            { return 1; }
            else {return (fibronase(i - 1) + fibronase(i - 2));}
        }

        //
        //Exercise 6: Iteration
        //Now that you are familiar with recursion, it's time to look at iteration. Iteration is one
        //function that repeats the same until the target is reached.So an iterative function for
        //to make the previous calculation if the ninth odd number should look like:
        //This method looks if n is zero, in which case it returns the first odd number 1. Otherwise, it takes
        //the 1 + 2 until the result becomes the ninth odd number.
        //1. Illustrate the paper paths for IterativeOdd (1), IterativeOdd(3) and
        //IterativeOdd(5) to understand the iteration.
        //2. Create an IterativeEven (int n) function to iteratively calculate the nth even number.
        //3. Implement an iterative version of the fibonacci Calculator.
        //Question:
        //Assume your newly acquired knowledge of iteration, recursion and memory management. Which of
        //The above features are most memorable and why?
        public int iterationOdd(int i)
        {
            if (i == 0)
            {
                return 1;
            }
            else
            { 
            int result = 1;
                for (int j = 1; j <= i; j++)
                {
                    result += 2;
                };
                return result;
            }
         }
        public int iterationEven(int i)
        {
            if (i == 0)
            {
                return 2;
            }
            else
            {
                int result = 2;
                for (int j = 1; j <= i; j++)
                {
                    result += 2;
                };
                return result;
            }
        }
        public IEnumerable<int> iterationfibro(int i)
        {
            int result = 0; 
            int result1 = 1;
            int result2 = 1;

            for (int j = 0; j <= i; j++)
            {
                if (j < 2)
                { result = 1; }
                else
                {
                    result = result1 + result2;
                    result2 = result1;
                    result1 = result;
                }
                    yield return result;
                };

                //yield return result;
         }
    }
}
