﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ovning4
{
    class Program
    {
        static void Main(string[] args)
        {
            int caseSwitch;
            bool exitSwitch = false;
            Additional addFunctions = new Additional();
            //
            // Main Menu: 0 for Exit
            //
            do
            {
                Console.WriteLine("-----------------------------------------------------------------------------------");
                Console.WriteLine("Welcome to the Main Menu");
                Console.WriteLine("Please type:");
                Console.WriteLine("  1 - for ExamineList()");
                Console.WriteLine("  2 - for ExamineQueue ()");
                Console.WriteLine("  3 - for ExamineStack()");
                Console.WriteLine("  4 - for CheckParanthesis()");
                Console.WriteLine("  5 - for RecursiveEven()");
                Console.WriteLine("  6 - for Iteration()");
                Console.WriteLine("  0 - for Exit");
                Console.WriteLine("-----------------------------------------------------------------------------------");

                caseSwitch = inputin();

                switch (caseSwitch)
                {
                    case 1:
                        //List
                        ExamineList();
                        break;
                    case 2:
                        //Queue
                        ExamineQueue();
                        break;
                    case 3:
                        //Stack
                        ExamineStack();
                        break;
                    case 4:
                        //CheckParanthesis 
                        CheckParanthesis();
                        break;
                    case 5:
                        //RecursiveEven 
                        string testLine = "";
                        Console.WriteLine("");
                        Console.WriteLine("Recursive Odd example");
                        Console.WriteLine("");
                        for (int i = 0; i < 10; i++)
                        { testLine+=$" {addFunctions.recursiveOdd(i)}";}
                        Console.WriteLine(testLine);
                        testLine = "";
                        Console.WriteLine("");
                        Console.WriteLine("Recursive Even example");
                        Console.WriteLine("");
                        for (int i = 0; i < 10; i++)
                        { testLine += $" {addFunctions.recursiveEven(i)}"; }
                        Console.WriteLine(testLine);
                        testLine = "";
                        Console.WriteLine("");
                        Console.WriteLine("Fibro example");
                        Console.WriteLine("");
                        for (int i = 0; i < 10; i++)
                        { testLine += $" {addFunctions.fibronase(i)}"; }
                        Console.WriteLine(testLine);
                        break;
                    case 6:
                        //Iteration
                        testLine = "";
                        Console.WriteLine("");
                        Console.WriteLine("Iteration Odd example");
                        Console.WriteLine("");
                        for (int i = 0; i < 10; i++)
                        { testLine += $" {addFunctions.iterationOdd(i)}"; }
                        Console.WriteLine(testLine);
                        testLine = "";
                        Console.WriteLine("");
                        Console.WriteLine("Iteration Even example");
                        Console.WriteLine("");
                        for (int i = 0; i < 10; i++)
                        { testLine += $" {addFunctions.iterationEven(i)}"; }
                        Console.WriteLine(testLine);
                        testLine = "";
                        Console.WriteLine("");
                        Console.WriteLine("Fibro example");
                        Console.WriteLine("");
                        //Test
                        foreach (var item in addFunctions.iterationfibro(10)) 
                        {
                 //           Console.WriteLine(item);
                            testLine += $" {item}";
                        }
                        Console.WriteLine(testLine);
                        Console.WriteLine("");
                        testLine = "";
                        for (int i = 0; i < 10; i++)
                        { testLine += $" {addFunctions.fibronase(i)}"; }
                        Console.WriteLine(testLine);
                        break;
                    case 0:
                        Console.WriteLine("Bye! Bye!");
                        exitSwitch = true;
                        break;
                    default:
                        Console.WriteLine($"You type {caseSwitch}, instead of 1,2,3,4 or 0. Please try again!");
                        break;
                }
            } while (!exitSwitch);

        }

        //---------------------------------------------------------------
        static int inputin()
        //
        // Input check 
        //
        {
            int val;
            bool parsed;
            do
            {
                var input = Console.ReadLine();
                parsed = int.TryParse(input, out val);
                if (!parsed)
                {
                    Console.WriteLine("Incorrect input! Please try again");
                }
            } while (!parsed);
            return val;
        }

        //  Exercise 1: ExamineList()

        //A list is an abstract data structure that can be implemented in a variety of ways.At this
        //you should be familiar with the team class. Unlike arrays, lists do not have one
        //predetermined size without size increases as the number of items in the list increases.
        //However, the class of class has an underlying array that you are going to investigate.To see the size
        //In the list's underlying array, the Capacity method is used in the List class.
        //1. Explain clearly the implementation of the ExamineList method so that the survey becomes
        //feasible.
        //2. When does the list's capacity increase? (Thus, the size of the underlying array)
        //3. How much capacity increases?
        //4. Why does not the list's capacity increase at the same rate as elements are added?
        //5. Reduces capacity when items are removed from the list?
        //6. When is it then advantageous to use a custom array instead of a list?
        //---------------------------------------------------------------------
        private static void ExamineList()
        {
            int caseSwitch;
            bool exitSwitch = false;
            var rnd = new Random();
            var testList = new List<int>();
            //
            // ExamineList Menu: 0 for Exit
            //
            do
            {
                Console.WriteLine("-----------------------------------------------------------------------------------");
                Console.WriteLine("Welcome to the ExamineList Menu Menu");
                Console.WriteLine("Please type:");
                Console.WriteLine("  5 - for ADD list item with int random value.");
                Console.WriteLine("  6 - for REMOVE first added list item.");
                Console.WriteLine("  0 - for return to Main menu");
                Console.WriteLine("-----------------------------------------------------------------------------------");
                Console.WriteLine("");
                Console.WriteLine($"TESTLIST contains:");
                foreach (var item in testList)
                {
                    Console.WriteLine($"Value: {item}");
                }
                Console.WriteLine($"Total list items: {testList.Count}  Capacity: {testList.Capacity}");


                caseSwitch = inputin();

                switch (caseSwitch)
                {
                    case 5://Add item
                        var rndValue = rnd.Next(0, 1000);
                        testList.Add(rndValue);
                        Console.WriteLine("");
                        Console.WriteLine($"Added new item: {rndValue}");
                        Console.WriteLine("");
                        break;
                    case 6: //Remove Item
                        
                            if (testList.Count > 0)
                        { 
                        Console.WriteLine(""); Console.WriteLine($"Was removed value: {testList[0]}"); Console.WriteLine("");
                         testList.Remove(testList[0]);
                        }
                        else

                        {
                            Console.WriteLine(""); Console.WriteLine("Cound't remove from empty list!"); Console.WriteLine("");
                        }
                        break;
                    case 0:
                        Console.WriteLine("Bye! Bye!");
                        exitSwitch = true;
                        break;
                    default:
                        Console.WriteLine($"You type {caseSwitch}, instead of 5,6 or 0. Please try again!");
                        break;
                }
            } while (!exitSwitch);

        }
        //Exercise 2: ExamineQueue ()
        //The data structure queue (implemented in the Queue class) works according to First In First Out(FIFO)
        //principle.Thus, the first element added will be the one that is removed first.
        //1. Simulate the following queue on paper:
        //a.ICA opens and queue until checkout is empty
        //b. Kalle stands in the queue
        //c.Greta is in queue
        //d. Kalle gets expedited and leaves queue
        //e.Stina sets herself in queue
        //f. Greta gets expedited and leaves queue
        //g.Olle sets herself in queue
        //hrs. …
        //2. Implement the TestQueue method. The method will simulate how a queue works
        //by allowing the user to set elements in the queue (enqueue) and remove elements
        //out of queue (dequeue). Use the Queue class to help implement the method.
        //Simulate the ICA queue using your program.
        private static void ExamineQueue()
        {
                int caseSwitch;
                bool exitSwitch = false;
                var rnd = new Random();
                var testQueue = new Queue<int>();
                //
                // ExamineQueue Menu: 0 for Exit
                //

                do
                {
                    Console.WriteLine("-----------------------------------------------------------------------------------");
                    Console.WriteLine("Welcome to the ExamineQueue Menu Menu");
                    Console.WriteLine("Please type:");
                    Console.WriteLine("  5 - for ADD queue item with int random value.");
                    Console.WriteLine("  6 - for REMOVE queue item.");
                    Console.WriteLine("  0 - for return to Main menu");
                    Console.WriteLine("-----------------------------------------------------------------------------------");
                    Console.WriteLine("");
                    Console.WriteLine($"TESTQUEUE contains:");
                    foreach (var item in testQueue)
                    {
                        Console.WriteLine($"Value: {item}");
                    }
                    Console.WriteLine($"Total list items: {testQueue.Count}");


                    caseSwitch = inputin();

                    switch (caseSwitch)
                    {
                        case 5://Add item
                        var rndValue = rnd.Next(0, 1000);
                            testQueue.Enqueue(rndValue);
                            Console.WriteLine(""); Console.WriteLine($"Added new item: {rndValue}");  Console.WriteLine("");
                        break;
                        case 6: //Remove Item
                            if (testQueue.Count>0)
                            {
                            Console.WriteLine(""); Console.WriteLine($"Removed first item: {testQueue.Peek()}"); Console.WriteLine("");
                            testQueue.Dequeue ();
                             }
                            else
                            { Console.WriteLine("Cound't remove from empty list!"); }
                            break;
                        case 0:
                            Console.WriteLine("Bye! Bye!");
                            exitSwitch = true;
                            break;
                        default:
                            Console.WriteLine($"You type {caseSwitch}, instead of 5,6 or 0. Please try again!");
                            break;
                    }
                } while (!exitSwitch);

            
        }

        //----------------------------------------------------------------------------
        //Exercise 3: ExamineStack()
        //Stacks are reminiscent of queues, but a big difference is that stacks use First In Last
        //Ut(FILO) principle.Thus, the element that is pushed in first(push) is that
        //will be removed last(pop).
        //1. Simulate the ICA Gender again on paper.This time with a stack.Why is it
        //not so smart to use a stack in this case?
        //2. Implement a ReverseText method that reads a string from the user and
        //Using a stack, turn order on the character sequence and then print it
        //reverse string to the user.
        private static void ExamineStack()
        {
            Console.WriteLine("");
            Console.WriteLine("Please input random string!");
            var inputString = Console.ReadLine();
            Console.WriteLine($"Reverse string is :{ReverseText(inputString)}");

        }

        private static string ReverseText(string inputString)
        {
            string reversString = "";
            var stack = new Stack<char>();
           foreach (char v in inputString)
            {
             //   Console.WriteLine(v);
                stack.Push(v);
            }
            var j = stack.Count; 
            for (int i = 0; i < j; i++)
            {
              reversString += stack.Pop();
            }
      return reversString; 
        }
        //------------------------------------------------------------------------------
        //   Exercise 4: CheckParanthesis()
        //  You should now have sufficient knowledge of the above - mentioned data structures to solve the following
        //  problem.
        //  We say that a string is well - formed if all parentheses that are opened are also closed properly.
        //  The opening and closing of an parenthesis is dictated by the following rules:
        //  ),},] may only occur after the respective(, {, [
        //   Each parenthesis that opens must be closed ie "(" followed by ")"
        //  For example, ([{}] ({})) is well-formed but not({)}. Furthermore, a string may contain other characters,
        //  For example, "List <int> list = new List <int> () {2, 3, 4};" well-formed.So we care about it
        //  brackets!
        //  1. Create using your new knowledge functionality to control a well-formed
        //  hard on paper.You will use some of the data structures we use
        //  just gone through. What data structure do you use?
        //  2. Implement the functionality of the CheckParantheses method.Let the program read
        //  in a string from the user and return an answer that reflects whether
        //  The string is well-formed or not.
        private static void CheckParanthesis()
        {
            // Create test list
            Console.WriteLine("");
            Console.WriteLine("CheckParanthesis() will check if all parentheses that are opened are also closed properly");
            Console.WriteLine("Please enter test string or leave it empty for default value: 1([({23{ 456}})7]8(([]){}))");
            Console.WriteLine("");
            var substrings = new List<char>();
            string testPattern= Console.ReadLine();
            int ifnopattern = 0;
            if (string.IsNullOrEmpty(testPattern)){ testPattern = "1([({23{ 456}})7]8(([]){}))"; }

            Console.WriteLine($"Test string: {testPattern}");
            Console.WriteLine("");
            foreach (char v in testPattern)
            {
                substrings.Add(v);
            }

            //Stack
            Stack<char> skobochki = new Stack<char>();
            //Dictionary for pair pattern!
            var pattern = new Dictionary<char, char>()
             {
                 { '(',')' }, {'{','}'},{'[',']'}
             };
            //Main cicle
            for (int i = 0; i < substrings.Count; i++)
            {
                //          Console.WriteLine($"Current: {substrings[i]}");
                if (pattern.ContainsKey(substrings[i])) //Check for pattern key - Left side
                {
                    skobochki.Push(substrings[i]);
                    //Console.WriteLine($"Push: {substrings[i]}");
                    ifnopattern++;
                }
                else if (pattern.ContainsValue(substrings[i])) //Check for pattern value - Right side
                {
                    if (skobochki.Count != 0)
                    {
                        if (pattern[skobochki.Peek()] == substrings[i]) //Stack value closed by current;
                        {

                            Console.WriteLine($"Closing pattern on position {i}:{skobochki.Peek()} {substrings[i]}");
                            skobochki.Pop();
                        }
                        else
                        {
                            //right value <> left value
                            Console.WriteLine($"Wrong pattern on position {i}:{skobochki.Peek()} {substrings[i]}");
                            return;
                        }

                    }
                    else
                    {
                        Console.WriteLine($"Right item doesn't exist -  empty stack on position,{i}: {substrings[i]}");
                        return;
                    }

                }

            }
            if (skobochki.Count != 0)
            {
                Console.WriteLine($"Epic Fail! Not Empty Stack. Wrong elements left in Stack: {skobochki.Count}");
            }
            else if (ifnopattern > 0)
            {
                Console.WriteLine("");
                Console.WriteLine($"Epic Win! All parentheses that are opened are also closed properly.");
            }
            else
            {
                Console.WriteLine("");
                Console.WriteLine($"String w/o pattern, please try something else!");
            }
        }

    }
}
