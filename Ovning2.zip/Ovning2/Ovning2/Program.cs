﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ovning2
{
    class Program
    {
        static void Main(string[] args)
        {
            int caseSwitch;
            bool exitSwitch = false;
            //
            // Main Menu: caseSwitch: =1 for Ages, =2 for Repeat, =3 for Third word, =0 for Exit
            //
            do
            {
                Console.WriteLine("-----------------------------------------------------------------------------------");
                Console.WriteLine("Welcome to the Main Menu");
                Console.WriteLine("Please type:");
                Console.WriteLine("  1 - for AGES MODULE");
                Console.WriteLine("  2 - for REPEAT MODULE");
                Console.WriteLine("  3 - for SPLIT MODULE");
                Console.WriteLine("  0 - for Exit");
                Console.WriteLine("-----------------------------------------------------------------------------------");

                caseSwitch = inputin();

                switch (caseSwitch)
                {
                    case 1:
                        //Console.WriteLine("Case 1");
                        Ages();
                        break;
                    case 2:
                        //Console.WriteLine("Case 2");
                        Repeater();
                        break;
                    case 3:
                        //Console.WriteLine("Case 3");
                        Splitter();
                        break;
                    case 0:
                        Console.WriteLine("Bye! Bye!");
                        exitSwitch = true;
                        break;
                    default:
                        Console.WriteLine($"You type {caseSwitch}, instead of 1,2,3 or 0. Please try again!");
                        break;
                }
            } while (!exitSwitch);
        }
        //
        // Input check 
        //
        static int inputin()
        {
            int val;
            bool parsed;
            do
            {
                var input = Console.ReadLine();
                parsed = int.TryParse(input, out val);
                if (!parsed)
                {
                    Console.WriteLine("Incorrect input! Please try again");
                }
            } while (!parsed);
            return val;
        }
        //AGE MODULE
        // age - int variable contains age of users 
        // ageinfo - string contains price description info
        // Price - double contains price
        static void Ages()
        {
            Console.WriteLine("-----------------------------------------------------------------------------------");
            Console.WriteLine("Welcome to the AGES MODULE!");
            Console.WriteLine("Please input your age correctly to getting true price!");
            Console.WriteLine("-----------------------------------------------------------------------------------");
            double Price = 0;
            string ageinfo;
            //Price depends age
            int age = inputin();
            if (age < 0)
            {
                Price = 999999;
                ageinfo="Ups!!!Your age is under 0, that";
            }
            else if (age <5)
            {
                Price = 0;
                ageinfo = "Free";
            }
            else if (age <= 20)
            {
                Price = 80;
                ageinfo = "Children";
            }
            else if (age <= 64)
            {
                Price = 120;
                ageinfo = "Adult";
            }
            else if (age <= 100)
            {
                Price = 90;
                ageinfo = "Pensioner";
            }
            else
            {
                Price = 0;
                ageinfo = "Free";
            }

            Console.WriteLine($"{ageinfo} price: {Price}kr");

        }
        // REPEATER MODULE
        // outtext - string variable contains concatanated values from every input
        //
        static void Repeater()
        {
            Console.WriteLine("-----------------------------------------------------------------------------------");
            Console.WriteLine("Welcome to the REPEAT MODULE!");
            Console.WriteLine("Please input something 10 times!");
            Console.WriteLine("-----------------------------------------------------------------------------------");
            string outtext="";
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine($"Please input value for {i} step");
                outtext += $" Input {i} was {Console.ReadLine()}";

            }
            Console.WriteLine($"You type something strange: {outtext}");
        }
        // SPLITTER MODULE
        // intext - input string must containg several words
        // delimeter - char variable contains delimeter value, default - space
        // substring - string array 
        static void Splitter()
        {
            Console.WriteLine("-----------------------------------------------------------------------------------");
            Console.WriteLine("Welcome to the SPLITER MODULE!");
            Console.WriteLine("Please input string with several words!");
            Console.WriteLine("-----------------------------------------------------------------------------------");
            string intext = Console.ReadLine();
            //Console.WriteLine(intext);
            Char delimiter = ' ';
            String[] substrings = intext.Split(delimiter);

            substrings = substrings.Where(subst => !string.IsNullOrEmpty(subst)).ToArray();

/*            i = 0;
            foreach (var subst in substrings)
            {
                i++;
                Console.WriteLine($"The third word was 2:{i} {subst}");
            }*/

            try
            {
                Console.WriteLine($"The third word was:{substrings[3]}");
            }
            catch
            {
                Console.WriteLine("Not enought words in input string!");
                return;
            }

            /*        try
                    {
                        int i = 0;
                        foreach (var subst in substrings)
                        {
                            if (!String.IsNullOrEmpty(subst))
                             {
                                i++;
                                if (i == 3)
                                {
                                    Console.WriteLine($"The third word was:{subst}");
                                }

                             }

                        }
                    }
                    catch
                    {
                        Console.WriteLine("Not enought words in input string!");
                        return;
                    } */

        }
    }
}
