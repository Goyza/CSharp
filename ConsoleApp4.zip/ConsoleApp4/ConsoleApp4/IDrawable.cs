﻿using System;

namespace ConsoleApp4
{
    internal interface IDrawable
    {
        ConsoleColor Color { get; set; }
        string Symbol { get; set; }
    }
}