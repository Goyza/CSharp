﻿using System.Collections.Generic;

namespace ConsoleApp4
{
    public class Vendor
    {
        public string Lname { get; set; }
        public string Fname { get; set; }
        public IEnumerable<Vendor> RetrivalAll()
        {
            var vendors = new List<Vendor>()
            {
                { new Vendor(){Lname="LTest1",Fname="FTest1" } },
                { new Vendor(){Lname="LTest2",Fname="FTest2" } },
                { new Vendor(){Lname="LTest3",Fname="FTest3" } },
                { new Vendor(){Lname="LTest4",Fname="FTest4" } }
            };
            return vendors;
        }
    }

}