﻿using ConsoleApp4.Entities;
using System;

namespace ConsoleApp4
{
    internal class Cell : IDrawable
    {
        public string Symbol { get; set; } = ".";
        public ConsoleColor Color { get; set; } = ConsoleColor.DarkGray;
        public Item Item { get; set; }
    }
}