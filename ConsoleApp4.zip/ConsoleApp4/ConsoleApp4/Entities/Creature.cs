﻿using System;
namespace ConsoleApp4.Entities
{
    internal class Creature: IDrawable
    {
        public string Symbol { get; set; } 
        public ConsoleColor Color { get; set; } 

        public int Health { get; set; }
        public int Damage { get; set; }

        public Creature(string symbol, ConsoleColor color)
        {
            Symbol = symbol;
            Color = color;
        }
    }
}