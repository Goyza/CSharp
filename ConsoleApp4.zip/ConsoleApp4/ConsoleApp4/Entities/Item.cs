﻿namespace ConsoleApp4.Entities
{
    public class Item
    {
    }
}