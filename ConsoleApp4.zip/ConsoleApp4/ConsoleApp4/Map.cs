﻿using ConsoleApp4.Entities;
using System;

namespace ConsoleApp4
{
    internal class Map
    {
        private int width;
        private int height;
        private Cell[,] cells;
        public Hero Hero { get; set; }
                
        public Map(int width, int height)
        {
            this.width = width;
            this.height = height;
            cells = new Cell[width, height];
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    cells[x, y] = new Cell();
                }

            }

        }
        internal void Draw()
        {
            // cells[5, 6].Symbol = "@";
            // cells[5, 6].Color = ConsoleColor.Red;
            var prevColor = Console.ForegroundColor;
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    Console.Write(" ");
                    Cell cell = cells[x, y];
                    IDrawable drawable = cells[x, y];

                    if (Hero.X == x && Hero.Y == y) drawable = Hero;
                    //{cells[x, y] = Hero;}
                    // Console.ForegroundColor = cell.Color;
                    // Console.Write(cell.Symbol);
                    //else 
                    Console.ForegroundColor = drawable.Color;
                    Console.Write(drawable.Symbol);
                
                 }
                Console.WriteLine();
            }
            Console.ForegroundColor = prevColor;

        }
        internal bool InvalidCell(int x, int y)
        {
            return x < 0 || y < 0 || x >= width || y >= height;
        }
    }
}