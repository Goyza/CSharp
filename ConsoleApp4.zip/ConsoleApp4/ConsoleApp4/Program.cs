﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            var repository = new Vendor();

            var vendors = repository.RetrivalAll();

            foreach (var item in vendors)
            {
                Console.WriteLine($"{item.Lname} {item.Fname}");
            }

            //  var sql = vendors.Where(filteR);
            //from v in vendors where v.Lname.Contains("LTest2") select v;
            var sql = vendors.Where(v => v.Lname.Contains("Test")).OrderBy(v=>v.Fname); 

             foreach (var item in sql.ToList())
            {
                Console.WriteLine($"{item.Lname} {item.Fname}");
            }

            // bool filteR(Vendor v) => v.Lname.Contains("LTest2");
            //bool playAgain;
            do
            {
                var game = new Game();
                game.Start();
                Console.WriteLine("Next Y/N");
            //    playAgain = Console.ReadKey(intercept: true).Key == ConsoleKey.Y;
            } while (Console.ReadKey(intercept: true).Key == ConsoleKey.Y);
            Console.WriteLine("Hej");
            
        }

    }
}
