﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ovning3
{
    public class Animal
    {
        //  1. Create the Animal class
        //  2. Fill the Animal class With properties(properties) Which all animals should have.Tex: name, weight, age.
        //  3. Create a constructor to create an Animal.

        public string Name { get ; set; }
        public double Weight { get; set ; }
        public int Age { get ; set ; }
        
        public Animal(string _name, double _weight, int _age)
        {
            Name = _name; Weight = _weight; Age = _age;
        }  
          
        //  1. Create the Stats () method in the Animal category Which has the return type string. 
        //     The method should be able to be overridden In its subclasses. The method should return all properties (properties) As the animal has.
        public virtual string Stats()
        {
            return $"Type:{GetType().Name}, Name:{Name}, Weight:{Weight}, Age:{Age}"; ;
        }
    }

    //  4.  Create Subclasses(inherits from Animal): Horse, Dog, Hedgehog, Worm, Bird.
    //  5.  Give these at least one unique feature Var.What characteristic it is is not the important thing here.
    //      Example: Worm IsPoisonous, Hedgehog QuantOfSpikes, Bird WingSpan Etc.
    // Horse class
    public class Horse: Animal
    {
        public Horse(string _name, double _weight, int _age, double _maneLength) : base(_name,_weight, _age)
        {
            ManeLength = _maneLength;
        }

        public double ManeLength { get ; set; }
        //     The method should be able to be overridden In its subclasses. The method should return all properties (properties) As the animal has.
        public override string Stats()
        {
            return $"{base.Stats()}, ManeLength:{ManeLength}";

        }
    }
    // Dog class
    public class Dog : Animal
    {
        public Dog(string _name, double _weight, int _age, string _breed) : base(_name, _weight, _age)
        {
            Breed = _breed;
        }

        public string Breed { get; set; }
        //     The method should be able to be overridden In its subclasses. The method should return all properties (properties) As the animal has.
        public override string Stats()
        {
            return $"{base.Stats()}, Breed:{Breed}";

        }
        // 13.Create a new method with any name in the Dog category, which returns only an optional string.
        public string ReturnSomething()
        {
            return $"BREEEEDDDD:{Breed}";

        }
    }
    // class Hedgehog
    public class Hedgehog : Animal
    {
        public Hedgehog(string _name, double _weight, int _age, double _quantyOfSpikes) : base(_name, _weight, _age)
        {
            QuantyOfSpikes = _quantyOfSpikes;
        }
        public double QuantyOfSpikes { get; set; }
        //     The method should be able to be overridden In its subclasses. The method should return all properties (properties) As the animal has.
        public override string Stats()
        {
            return $"{base.Stats()}, QuantyOfSpikes:{QuantyOfSpikes}";

        }
    }
    // class Worm
    public class Worm : Animal
    {
        public Worm(string _name, double _weight, int _age, bool _isPoisonous) : base(_name, _weight, _age)
        {
            IsPoisonous = _isPoisonous;
        }
        public bool IsPoisonous { get; set; }
        //     The method should be able to be overridden In its subclasses. The method should return all properties (properties) As the animal has.
        public override string Stats()
        {
            return $"{base.Stats()}, IsPoisonous:{IsPoisonous}";

        }
    }
    //
    // class Bird
    public class Bird : Animal
    {
        public Bird(string _name, double _weight, int _age, double _wingSpan) : base(_name, _weight, _age)
        {
            WingSpan = _wingSpan;
        }
        public double WingSpan { get; set; }
        //     The method should be able to be overridden In its subclasses. The method should return all properties (properties) As the animal has.
        public override string Stats()
        {
            return $"{base.Stats()}, WingSpan:{WingSpan}";

        }
    }
    // 6. Now create the following three classes: Pelican, Flamingo And Swan.These are inherited from Bird.
    // 7. Give these at least one unique feature.
    // 8. Q: If during development we find that all birds need a new attribute, in which class should we add it? Class Bird
    // 9. Q: If all animals need the new attribute, where would you add it then? Class Animal
    //class Pelican 
    public class Pelican : Bird
    { 
        public Pelican(string _name, double _weight, int _age, double _wingSpan, double _beakSize) : base(_name, _weight, _age, _wingSpan)        {
            BeakSize = _beakSize;
        }
        public double BeakSize { get; set; }
        //     The method should be able to be overridden In its subclasses. The method should return all properties (properties) As the animal has.
        public override string Stats()
        {
            return $"{base.Stats()}, BeakSize:{BeakSize}";

        }
    }
    //class Flamingo
    public class Flamingo : Bird
    {
        public Flamingo(string _name, double _weight, int _age, double _wingSpan, double _legSize) : base(_name, _weight, _age, _wingSpan)
        {
            LegSize = _legSize;
        }
        public double LegSize { get; set; }
        //     The method should be able to be overridden In its subclasses. The method should return all properties (properties) As the animal has.
        public override string Stats()
        {
            return $"{base.Stats()}, LegSize:{LegSize}";

        }
    }
    //class Swan
    public class Swan : Bird
    {
        public Swan(string _name, double _weight, int _age, double _wingSpan, double _neckSize) : base(_name, _weight, _age, _wingSpan)
        {
            NeckSize = _neckSize;
        }
        public double NeckSize { get; set; }
        //     The method should be able to be overridden In its subclasses. The method should return all properties (properties) As the animal has.
        public override string Stats()
        {
            return $"{base.Stats()}, NeckSize:{NeckSize}";

        }
    }
}
