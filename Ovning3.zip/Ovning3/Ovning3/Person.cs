﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ovning3
{
    public class Person
    {
        // 1. Create a Class Person and give it the following private attributes:
        //    age, fName, lName, height, weight
        //    Create public properties with gets and sets that retrieve or add assigned variable.
        //    Instantize a person in program.cs, do you directly address the variables?
        public Person()
        {        
        _fName="";
        _lName="";
        _age=0;
        _height=0;
        _weight=0;
        }
        public string Fname
        {get
            {return _fName.ToUpper();}
         set
            { _fName=value;}
        }
        public string Lname
        {
            get
            { return _lName.ToUpper(); }
            set
            { _lName = value; }
        }
        public int Age
        {
            get
            { return _age; }
            set
            { _age = value; }
        }
        public double Height
        {
            get
            { return _height; }
            set
            { _height = value; }
        }
        public double Weight
        {
            get
            { return _weight; }
            set {
                _weight = value; }
        }
        private string _fName;
        private string _lName;
        private int _age;
        private double _height;
        private double _weight;
    }
}
