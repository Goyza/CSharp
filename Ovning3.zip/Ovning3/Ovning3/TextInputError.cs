﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ovning3
{
    class TextInputError: UserError
    // 5. Create a regular class TextInputError Inherited from UserError
    // 6. Write an override For UEMessage() So that it returns "Du prøvde å bruke en tekstinput i et numerisk felt. This fired an error! "
    {
        public override string UEMessage()
        {
            return "Du prøvde å bruke en tekstinput i et numerisk felt. This fired an error!";
        }

    }
}
