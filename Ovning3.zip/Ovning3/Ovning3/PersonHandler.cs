﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ovning3
{
    public class PersonHandler
    {
        // 2.   In order to encapsulate the Person objects, we will create the PersonHandler class - 
        //      a class whose purpose is to create and manage your Person objects.In the PersonHandler class, create the method:
        //      public void SetAge(Person pers, int age)
        //      Use the submitted person's Age property to set the person's age attribute via SetAge method.Instead of using only a property we have now abstracted with two layers.
        //  3.  In PersonHandler, type a method that creates a person with the specified values:
        //      public Person CreatePerson(int age, string fname, string lname, double height, double weight)
        //  4.  Continue creating methods in PersonHandler to handle all operations that you may want to do with a Person.
        //  5.  When this class is complete, comment on your previous instance of Person from Program.cs, and instead install a PersonHandler.Create some by doing that people and test your methods.
        public void SetAge(Person pers, int age)
        {
            pers.Age = age;
        }
        public void Setfname(Person pers, string fname)
        {
            pers.Fname = fname;
        }
        public void Setlname(Person pers, string lname)
        {
            pers.Lname = lname;
        }
        public void Setheight(Person pers, double height)
        {
            pers.Height = height;
        }
        public void Setweight(Person pers, double weight)
        {
            pers.Weight = weight;
        }
        public Person CreatePerson(int age,string fname, string lname, double height, double weight)
        {
            Person chg = new Person();
            SetAge(chg, age);
            Setfname(chg, fname);
            Setlname(chg, lname);
            Setheight(chg, height);
            Setweight(chg, weight);
            return chg; 
        }
        public void InvertPersonNames(Person pers)
        {
            string a = pers.Lname;
            pers.Lname = pers.Fname;
            pers.Fname = a;
        }
    }
}
