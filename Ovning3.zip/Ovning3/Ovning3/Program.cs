﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ovning3
{
    public class Program
    {
        public static void Main()
        {
            //  3.1 Encapsulation. --------------------------------------------------------------------------------------------------
            //  4.  Continue creating methods in PersonHandler to handle all operations that you may want to do with a Person.
            //  5.  When this class is complete, comment on your previous instance of Person from Program.cs, 
            //      and instead install a PersonHandler.Create some by doing that people and test your methods.
            AnyKeyToContinue("3.1 Encapsulation", false); //Stop
            PersonHandler pershand = new PersonHandler();
            Person person = pershand.CreatePerson(48, "Bespalov", "Pavel", 165, 73);
            Console.WriteLine($"{person.Fname},{person.Lname},{person.Age},{person.Weight},{person.Height}!");
            // TEST FRAGMENT ON
            pershand.InvertPersonNames(person);
            //  TEST FRAGMENT OFF
            Console.WriteLine($"{person.Fname},{person.Lname},{person.Age},{person.Weight},{person.Height}!");
            //
            // 3.2 inheritance--------------------------------------------------------------------------------
            // 4.Create some animals(of different types) in your list.
            // 5.Print which animals are in the list using a foreach loop
            // 6.Create a list for dogs.
            // 7.F: Try to add a horse to the list of dogs.Why does not it work ?
            // 8.Q : What kind of list must be in order for all classes to be stored together ?
            // 9.Print all Animals Stats() through a foreach loop.
            // 10.Test and see how it works.
            // 11.F: Explain what is happening.
            // 12.Print the Stats() method only for all dogs through a foreach on Animals.
            // 13.Create a new method with any name in the Dog category, which returns only an optional string.
            // 14.Will you access the method from Animals List? 
            // 15.F : Why not ?
            // 16.Find a way to print your new method, however, through a foreach on Animals

            // Create some animals(of different types) in your list.
            AnyKeyToContinue("3.2 inheritance", true); //Stop
            Animal animal = new Animal("Boris", 5, 9); //Just Animal
            Animals.Add(animal);
            //
            Animals.Add(new Animal("Erosha", 3, 9));  //Just Animal
            Animals.Add(new Dog("Sharik", 4, 8, "Simple"));  //Dog 1
            Animals.Add(new Dog("Inna", 5, 9, "Collie"));//Dog 2
            Animals.Add(new Dog("Alla", 5, 9, "Sheepdog")); //Dog 3  
            Animals.Add(new Pelican("Dodo", 1, 2, 3, 4));//Pelican 1
            Animals.Add(new Flamingo("Yaya", 5, 6, 7, 8));//Flamingo 1

            AnyKeyToContinue("Animals Array", false); //Stop
            foreach (Animal a in Animals)
            {
                Console.WriteLine($"{a.Stats()}");
            }

            // 6.Create a Dogs list             
            Dog dog = new Dog("Alla", 5, 9, "Sheepdog");//Dog1 in Dog 
            Dogs.Add(dog);
            Dogs.Add(new Dog("Inna", 5, 9, "Collie"));//Dog 2 in Dog
            //
            // 13.Create a new method with any name in the Dog category, which returns only an optional string.
            //
            AnyKeyToContinue("Dogs Array with custom function", false); //Stop
            foreach (Dog a in Dogs)
            {
                Console.WriteLine($"{a.ReturnSomething()}, {a.Stats()}");
                //    Console.WriteLine($"{a.Stats()}");
            }

            // 12.Print the Stats() method only for all dogs through a foreach on Animals. 
            AnyKeyToContinue("Only Dogs from Animals Array", true); //Stop
            foreach (Animal a in Animals)
            {

                if (a is Dog)
                {
                    Console.WriteLine($"{a is Dog},{a.Stats()}");
                }
            }
            AnyKeyToContinue("Dog custom function from Animals Array", false); //Stop
            foreach (Animal a in Animals)
            {
                //if (a is Dog)
                //{
                //    Console.WriteLine($"{((Dog)a).ReturnSomething()}, {a.Stats()}");
                //}
                //else { Console.WriteLine($"{a.Stats()}"); }

                Console.WriteLine($"{(a as Dog)?.ReturnSomething() ?? a.Stats()}");
            }
            //    
            // 3.4 Polymorphism
            //---------------------------------------------------------------------
            // 7. In program.cs Main Method: Create a list of UserErrors And populate it with instances of NumericInputError And TextInputError.
            // 8. Print All UserErrors UEMessage () Through a foreach loop.
            // 9. Now create three own classes with three own definitions on UEMessage ()
            // 10. Test and see how it works.
            // 11. Q: Why is polymorphism important to master?
            // 12. Q: How can polymorphism change and improve code through a good structure?
            // 13. Q: What is the difference between an abstract class and an interface?
            AnyKeyToContinue("3.4 Polymorphism", false); //Stop
            UserError userNum = new NumericInputError();
            userErrors.Add(userNum);
            UserError userText = new TextInputError();
            userErrors.Add(userText);
            //
            userErrors.Add(new ErrorClass1());
            userErrors.Add(new ErrorClass2());
            userErrors.Add(new ErrorClass3());
            //
            AnyKeyToContinue("Error Array", false); //Stop
            foreach (UserError a in userErrors)
            {
                Console.WriteLine($"{a.UEMessage()}");
            }

            AnyKeyToContinue("The End", true); //Stop
        }
        //Header function
        private static void AnyKeyToContinue(string head, bool stop)
        {
           if (stop)
            {
                Console.WriteLine($" ");
                Console.WriteLine($"Press Any Key To Continue");
                string xxx = Console.ReadLine();
            }

            Console.WriteLine($" ");
            Console.WriteLine($"{head.ToUpper()}");
            Console.WriteLine($" ");
        }

        // Create a list of UserErrors
        public static List<UserError> userErrors = new List<UserError>();
        // Create a list of Animals In programs.cs that receive animals.
        public static List<Animal> Animals= new List<Animal>();
        // Create a list for dogs.
        public static List<Dog> Dogs = new List<Dog>();


    }    
}
