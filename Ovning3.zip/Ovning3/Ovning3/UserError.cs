﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ovning3
{
//    3.4 Polymorphism
// 1. Create the abstract class UserError
// 2. Create the abstract method UEMessage() that has the return type string.
// 3. Create a regular class NumericInputError Inherited from UserError
// 4. Type an override For UEMessage() So that it returns "You tried to use a numeric input in a text only field. This fired an error! "
// 5. Create a regular class TextInputError Inherited from UserError
// 6. Write an override For UEMessage() So that it returns "Du prøvde å bruke en tekstinput i et numerisk felt. This fired an error! "
// 7. In program.cs Main Method: Create a list of UserErrors And populate it with instances of NumericInputError And TextInputError.
// 8. Print All UserErrors UEMessage () Through a foreach loop.
// 9. Now create three own classes with three own definitions on UEMessage ()
// 10. Test and see how it works.
// 11. Q: Why is polymorphism important to master?
// 12. Q: How can polymorphism change and improve code through a good structure?
// 13. Q: What is the difference between an abstract class and an interface?
    public abstract class UserError
    {
        public abstract string UEMessage();
    }
}
