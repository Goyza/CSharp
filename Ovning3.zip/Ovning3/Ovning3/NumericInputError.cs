﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ovning3
{
    class NumericInputError: UserError
    {
        // 3. Create a regular class NumericInputError Inherited from UserError
        // 4. Type an override For UEMessage() So that it returns "You tried to use a numeric input in a text only field. This fired an error! "
        public override string UEMessage()
        {
            return "You tried to use a numeric input in a text only field. This fired an error! ";
        }
    }
}
